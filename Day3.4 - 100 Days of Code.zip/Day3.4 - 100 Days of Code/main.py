"""
This program with pizza ordering
Price of pizza varies depending on the size and top on added to it.
"""

size = input("Enter the size of pizza S, M or L: ")
add_peperonni = input("Do you want to add Peperonni Y or N: ")
add_cheese =  input("Do you need to add cheese Y or N: ")
net_amount = 0

if size == "S":
    net_amount = 15
    if add_peperonni == "Y":
        net_amount += 2
    if add_cheese == "Y":
        net_amount += 1
elif size == "M":
    net_amount = 20
    if add_peperonni == "Y":
        net_amount += 3
    if add_cheese == "Y":
        net_amount += 1
elif size == "L":
    net_amount = 25
    if add_peperonni == "Y":
        net_amount += 3
    if add_cheese == "Y":
        net_amount += 1
else:
    print("Something went wrong")
print(f"net amount to pay is {net_amount}")



